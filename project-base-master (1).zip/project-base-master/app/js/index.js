// Importing Helpers
import { NodeHelper,  FuncsHelper }  from './modules/Helpers'

// Getting Methods from Helpers
const { getNode, getNodes, addClass, removeClass, nextNode } = new NodeHelper()
const { imgLoadHelper } = new FuncsHelper()

// Invoking Functions from Helper
